@extends('layouts.main')

@section('container')
    <h1>Halaman About Forza</h1>
@endsection
